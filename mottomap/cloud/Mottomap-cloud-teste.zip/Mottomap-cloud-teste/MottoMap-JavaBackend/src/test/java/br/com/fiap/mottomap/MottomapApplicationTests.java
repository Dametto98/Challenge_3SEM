package br.com.fiap.mottomap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MottomapApplicationTests {

	@Test
	void contextLoads() {
	}

}
