package br.com.fiap.mottomap.model;

public enum Area {
    PRONTAS,
    MINHA_MOTTU,
    PROBLEMAS_SIMPLES,
    PROBLEMAS_GRAVES,
    IRRECUPERAVEIS
}
