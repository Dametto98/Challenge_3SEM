package br.com.fiap.mottomap.model;

public enum StatusMoto {
    ATIVA,
    INATIVA
}
