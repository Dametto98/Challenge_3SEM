package br.com.fiap.mottomap.model;

public enum ModeloMoto {
    MOTTU_SPORT,
    MOTTU_SPORT_ESD,
    MOTTU_E_MAX,
    POP_110I,
}
