package br.com.fiap.mottomap.model;

public enum CargoUsuario {
    ADM_GERAL,
    ADM_LOCAL,
    COL_PATIO,
    COL_MECANICO
}
