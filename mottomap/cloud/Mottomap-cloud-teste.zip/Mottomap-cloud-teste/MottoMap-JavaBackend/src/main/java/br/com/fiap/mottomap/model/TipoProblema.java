package br.com.fiap.mottomap.model;

public enum TipoProblema {
    MECANICO,
    CARROCERIA,
    ELETRICO,
    SEGURANCA,
    LEGAL,
    OUTRO
}
